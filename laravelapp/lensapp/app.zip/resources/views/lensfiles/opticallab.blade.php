<div class="customContainer welcome-row optical-row">
    <div class="row landing-page">
    <h1>Optical <span style="color: #345FF1;">Lab</span></h1>
    <h4>Please feel free to contact any of the following labs</h4>
				</div></div>