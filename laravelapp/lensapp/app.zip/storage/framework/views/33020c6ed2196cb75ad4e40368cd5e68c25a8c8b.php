<!--Assign product form to the collection -->
<div class="Custom-CollectionContainer AssignProducts hideData">
    
    <div class="edit-inner-container">
          <div class="Editnavigation-header">
              
               <div class="createNaviContent Editnavigation-Contents">
                 <span class="arrow-nav"><i class="fa fa-long-arrow-left"></i> </span><span class="EditBreadcrumbs__text">Back To Lens Collections</span>
              </div>
             
            
             <div class="edit-PageTitle">
                  <span class="edit-Titletxt"><span class="form-numbers">Step 1</span> <h2 class="create-titletxt">Assign <span style="color: #345FF1;">Products</span></h2></span>
              </div>
    
     </div>
     </div>
   
<form id="assignProductForm" method="GET">
      
      <div class="formAreahere allproducts-containers">
        
        <div class="assignerror error-msgs"></div>
        <div class="myassign-headers"></div>
         
        <div class="passignHidden hidden-inputFields"></div>
      </div>
      
 </form>
 </div> 
 <!--End Assign product form to the collection --><?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/createFormStepThree.blade.php ENDPATH**/ ?>