
<!-- Add lenses form -->
<div class="Custom-CollectionContainer AddLensesForm hideData">
    <div class="edit-inner-container">
          <div class="Editnavigation-header">
              <div class="createNaviContent Editnavigation-Contents">
                <span class="arrow-nav"><i class="fa fa-angle-left" style="font-size:15px; padding-right: 2px;"></i></span><span class="EditBreadcrumbs__text">Back To Lens Collections</span>
              </div>
             
              <div class="edit-PageTitle">
                  <span class="edit-Titletxt"><span class="form-numbers">Step 2 </span><h2 class="create-titletxt">Add Lenses</h2></span>
              </div>
          </div>
     
     
     </div>
   
<form class="" id="createLenseForm" method="GET">
     
      <div class="formAreahere lens-containers">
          <div class="lenserr error-msgs"></div>
         
         <div class="lens-formStart">
             <div class="mylensform-headers"><p class="tt">Add Lense to the Single Vision</p></div>
         
          <div class="add_lenses_FormArea"><div class="add_lenses_innerArea">
              <div class="hidden-inputFields"></div>
               <div class="row">
                   
               <div class="col-7 gp-lens-title">
               <span class="lensgroup-name"></span><span> Group 1</span></div>
               <div class="col-12 lens-title-col"><div class="display-pre-Heading">
               <label class="display_titles" for="pre-titles">Display Title
               <span class="display-title-inputFields"><input type="text" name="lens_title1" class="txt-inputs" value="Regular clear lens">
               </span>
               </label></div></div>
              </div>
           
            <!--- repeater 1 -->
            <div class="repeater">
            <div class="sortableContainer-table lens-table"><div class="table_of_lens_add"> <div><table class="table table-borderless">
                <thead>
                <tr class="lens-table-header">
                <th></th><th><strong>Lens Name</strong></th><th><strong>Shopify Id</strong></th><th><strong>Price</strong></th><th><strong>Rx Type</strong></th><th></th>
                </tr>
                </thead>
                 <tbody data-repeater-list="clearlens-group" class="lens-body">
                 <tr data-repeater-item="">
                <td class=""> <input type="hidden" name="id" id="clearlens-id"></td>
                <td class="lens-name"><input type="text" name="lens_names"></td>
                <td class="lens-shopifyID"></td>
                <td class="lens-price"><input type="text" name="lensprice" placeholder="100"></td>
                <td class="lens-Rx-type"><input type="text" name="rxtype" placeholder="single-vision"></td>
                <td class="lens-deleteIcon"><input data-repeater-delete="" type="button" value="Delete"></td>
                </tr></tbody><input data-repeater-create="" type="button" value="+Add"></table>
               
                </div></div>
                </div>
                </div>
                <!-- end repeater 1-->
               
                </div></div>
               
               <div class="add_lenses_FormArea"><div class="add_lenses_innerArea">
               <div class="row">
               <div class="col-7 gp-lens-title">
               <span class="lensgroup-name"></span><span> Group 2</span></div>
               <div class="col-12 lens-title-col"><div class="display-pre-Heading">
               <label class="display_titles" for="pre-titles">Display Title
               <span class="display-title-inputFields"><input type="text" name="lens_title2" class="txt-inputs" value="Anti Blue Light Lens">
               </span>
               </label></div></div>
               </div>
           
            <!-- repeater 2-->
            <div class="repeater">
            <div class="sortableContainer-table lens-table"><div class="table_of_lens_add"><div><table class="table table-borderless">
                <thead>
                <tr class="lens-table-header">
                <th></th><th><strong>Lens Name</strong></th><th><strong>Shopify Id</strong></th><th><strong>Price</strong></th><th><strong>Rx Type</strong></th><th></th>
                </tr>
                </thead>
                 <tbody data-repeater-list="antilens-group" class="lens-body">
                 <tr data-repeater-item="">
                <td class=""><input type="hidden" name="id" id="anti-lensid"></td>
                <td class="lens-name"><input type="text" name="antilens_names"></td>
                <td class="lens-shopifyID"></td>
                <td class="lens-price"><input type="text" name="antilensprice" placeholder="100"></td>
                <td class="lens-Rx-type"><input type="text" name="antirxtype" placeholder="single-vision"></td>
                <td class="lens-deleteIcon"><input data-repeater-delete="" type="button" value="Delete"></td>
                </tr></tbody><input data-repeater-create="" type="button" value="+Add"></table>
               
                </div></div>
                </div>
                </div>
                <!-- end repeater 2-->
               
                </div></div>
               
               
                </div>
         
           <div class="row form-btns">
     
    <div class="collectionSave col-12 form-save primary-button-container"><button type="submit" id="lensaved-btn" class="lensformsavedbtns Polaris-Button Polaris-Button--primary">
      <span class="Polaris-Button__Content"><span class="Polaris-Button__Text">Save &amp; Continue</span></span></button>
      </div>
      </div>
      </div>
         
 </form>
 </div> <!-- End Form-->
         
         
         
         
 <!--Assign product form to the collection -->
         
<div class="Custom-CollectionContainer AssignProducts hideData">
    <div class="edit-inner-container">
          <div class="Editnavigation-header">
              <div class="createNaviContent Editnavigation-Contents">
                <span class="arrow-nav"><i class="fa fa-angle-left" style="font-size:15px; padding-right: 2px;"></i></span><span class="EditBreadcrumbs__text">Back To Lens Collections</span>
              </div>
             
              <div class="edit-PageTitle">
                  <span class="edit-Titletxt"><span class="form-numbers">Step 3 </span><h2 class="create-titletxt">Assign products</h2></span>
              </div>
          </div>
     
     
     </div>
   
<form class="" id="assignProductForm" method="GET">
     
      <div class="formAreahere allproducts-containers">
        <div class="assignerror error-msgs"></div>
        <div class="myassign-headers"></div>
          <div class="passignHidden hidden-inputFields"></div>
         
         
      </div>
         
 </form>
 </div> <!-- End Form-->
         
         
          <!--End Assign product form to the collection --><?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/lenscollection.blade.php ENDPATH**/ ?>