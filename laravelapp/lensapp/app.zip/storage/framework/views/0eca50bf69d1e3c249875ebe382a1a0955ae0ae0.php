<div class="Custom-CollectionContainer OrdersData">
    
    <div class="edit-inner-container">
          <div class="Editnavigation-header">

             <div class="edit-PageTitle">
                 <h2 class="create-titletxt">Lens <span style="color: #345FF1;">Orders</span></h2></span>
              </div>
    
     </div>
     </div>
     
    <div class="formAreahere Orders-datas">
        <div class="ordersInner">
           
           <div class="orders-table hideData">
               <table class="order-details table-borderless">
                   <thead> 
                   <tr>
<th>Order</th><th>Date</th><th>Customer</th><th>Total</th><th>Status</th><th>Items</th>  
                   </tr>
                   </thead>
                  
                  <tbody>
                      <tr>
                          <td>#1001</td>
						  <td>Today at 9:30pm</td>
						  <td>Testing</td>
						  <td>Rs.0.00</td>
						  <td>Paid</td>
						  <td>1 item</td>
                      </tr>
					                        <tr>
                          <td>#1001</td>
						  <td>Today at 9:30pm</td>
						  <td>Testing</td>
						  <td>Rs.0.00</td>
						  <td>Paid</td>
						  <td>1 item</td>
                      </tr>
                  </tbody>
               </table>     
           </div> 
           
           <div class="orderempty-msg">
              <div class="order-txts">
                  <div class="order-imgs"> <img src="<?php echo $app_url;?>/resources/images/compliant.png" alt="Order_Icon" /></div>
                  <div class="about-orders">
                  <h4 class="main-txts">Your orders will show here</h4>
                  <p class="simple-txts">This is where you’ll see LensAdivizor orders and their fulfillment status.</p>
                  </div>
              </div> 
           </div>
            
        </div>
        </div>
     
     
</div>
<?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/orders.blade.php ENDPATH**/ ?>