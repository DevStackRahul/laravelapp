<!-- edit collection Form Start-->
    <div class="Custom-CollectionContainer edit-collectionPage hideData">
      
       <div class="edit-inner-container">
          <div class="Editnavigation-header">
               <div class="createNaviContent Editnavigation-Contents">
                <span class="arrow-nav"><i class="fa fa-long-arrow-left"></i> </span><span class="EditBreadcrumbs__text">Back To Lens Collections</span>
              </div>
              
             <div class="edit-PageTitle">
                 <span class="edit-Titletxt"><h2 class="create-titletxt">Edit <span style="color: #345FF1;">Collection</span></h2></span>
              </div>
          </div>
          </div>
          

<form id="editCollectionForm" method="GET">
 
  <div class="formAreahere editCollection-dataForm"> 
  </div>
  
</form>

</div> 
       
<!-- edit collection end--><?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/editCollectionForm.blade.php ENDPATH**/ ?>