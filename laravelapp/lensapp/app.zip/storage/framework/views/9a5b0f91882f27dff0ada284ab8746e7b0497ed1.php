<!-- Settings form-->
<div class="Custom-CollectionContainer Settings-Page">
     <div class="edit-inner-container">
          <div class="Editnavigation-header">
              
              <div class="edit-PageTitle">
                  <h2 class="create-titletxt">Lens <span style="color: #345FF1;">Settings</span></h2></span>
              </div>
          </div>
     </div> 
     
     <form method="GET" id="addnewSubCategory">
     <div class="formAreahere settingmainCat-forms">
           
          <div class="Form1heading">
              
          </div>    
               
     </div>
     </form>
     
     
</div>
 <?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/settings.blade.php ENDPATH**/ ?>