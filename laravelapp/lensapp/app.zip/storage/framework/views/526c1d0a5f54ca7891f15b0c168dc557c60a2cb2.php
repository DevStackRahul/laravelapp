<!-- edit collection Form Start-->
    <div class="Custom-CollectionContainer edit-collectionPage hideData">
      
       <div class="edit-inner-container">
          <div class="Editnavigation-header">
               <div class="createNaviContent Editnavigation-Contents">
                <span class="arrow-nav"><i class="fa fa-long-arrow-left"></i> </span><span class="EditBreadcrumbs__text">Back To Lens Collections</span>
              </div>
              
             <div class="edit-PageTitle">
                 <span class="edit-Titletxt"><span class="edit-Titletxt"><span class="form-numbers">Step 1</span> <h2 class="create-titletxt">Edit <span style="color: #345FF1;">Collection</span></h2></span>
              </div>
          </div>
          </div>
          

<form id="editCollectionForm" method="GET">
 
  <div class="formAreahere editCollection-dataForm"> 
  
    <div class="updatedatas">
    </div>
  
  
  <div class="row form-btns">
      
    <div class="collectionSave col-12 form-save primary-button-container"><button type="submit" id="updatecollect-btn" class="collSaveButton formsavedbtns Polaris-Button Polaris-Button--primary">
      <span class="Polaris-Button__Content"><span class="Polaris-Button__Text">Update & Continue</span></span></button>
      </div>
      </div>
  
  </div>
</form>

</div> 
       
<!-- edit collection end--><?php /**PATH /home/knwfv650zltb/public_html/laravelapp/lensapp/resources/views/lensfiles/editForms/editCollectionForm.blade.php ENDPATH**/ ?>