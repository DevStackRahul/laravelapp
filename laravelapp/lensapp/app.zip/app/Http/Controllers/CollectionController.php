<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\collectiontb;
use App\Curluse;

class CollectionController extends Controller
{
    // $shop = Auth::user();
    //return view('lensfiles.settings', ['mydata' => $shop]);
    public function fetchCollections(Request $request){
        $shop_name = $request->get('shops');
        $html = '';
       
        // load model function
        $colModels = new collectiontb();
        $all_data = $colModels->getCollections($shop_name);
        $col_Counts = count($all_data);
        $html .= '<div class="row empty-state"><div class="collection_Counts_heading">Showing '.$col_Counts.' Lens Collections</div></div>';
        $html .= '<div class="row lens-collectionsData"><div class="col"><div class="coltable-responsive-xl"><table class="colltable colltable-borderless colltable-hover"><tbody>';
        foreach($all_data as $rowdata){
            //print_r($rowdata);
            $collectionID = $rowdata->col_id;
            $collectionName = $rowdata->col_name;
            $collectionProducts_Count = $rowdata->col_products_count;
           
            $html .= '<tr class="collections-table-row">';
            $html .= '<td class="text-left no-hover-checkbox"><label class="Polaris-Choice" for="PolarisCheckbox1">
            <span class="Collec_Polaris-Checkbox">
            <input id="PolarisCheckbox1" name="collections-'.$collectionID.'" type="checkbox" class="Polaris-Checkbox__Input" aria-invalid="false" role="checkbox" aria-checked="false" value="">
            </span></td>';
            $html .= '<td class="text-left cursor collections-table-td" data-colid="'.$collectionID.'">
            <span class="col-title-h2"><strong>'.$collectionName.'</strong></span>
            <span class="collections-product_totals">'.$collectionProducts_Count.' Products</span>
            </td>
            <td class="text-right col-edit"><a href="javascript:void(0)" class="collect-edit-btn" onclick="editcollection('.$collectionID.')" data-id="'.$collectionID.'">Edit</a></td>
            <td class="text-right col-delete"><a href="javascript:void(0)" class="collect-delete-btn" onclick="deletecollection('.$collectionID.')" data-id="'.$collectionID.'">Delete</a></td>';
           
            $html .= '</tr>';
           
        }
       
        $html .= '</tbody></table></div></div></div>';
       
        echo $html;
         
    }
   
   
    /** function deleteCollections**/
    public function deleteCollections(Request $request){
        $shop_name = $request->get('shops');
        $col_id = $request->get('delcol');
       
        DB::delete('delete from savedcollectiondata where colection_id = ?',[$col_id]);
        DB::delete('delete from collectiontb where col_id = ?',[$col_id]);
       
        echo 'Collection delete successfully!';
       
       
    }
   
   
    /** Default collection Save**/
    public function saveDefaultCollections(Request $request){
        $shop_name = $request->get('shops');
       
        // form data
        $collection_title = $request->get("collection_title");
        $collection_main_category_id = $request->get("maincategory");
        $collection_main_category_title = $request->get("category_title");
        $collection_main_category_desc = $request->get("category_desc");
       
        $subArray = array();
       
        if(!empty($request->get("maincategory"))){
       
        if(!empty($request->get("subcats"))){
        $all_sub_catsids = $request->get("subcats");
        $totalsubcats = count($all_sub_catsids);
         $subcategories = implode(",",$all_sub_catsids);
        //echo $subcategories;
        }else{
            $subcategories = '';
        }
       
       
         $fetch_prescriptionName = DB::table('lenscategory')->Where('ID', $collection_main_category_id)->get();
          // print_r($fetch_prescriptionName);
           //exit;
                    $typeName = $fetch_prescriptionName[0]->catname;
                    $typeDesc = $fetch_prescriptionName[0]->catdesc;
                   
        if($collection_main_category_title == ''){
            $collection_main_category_title = $typeName;
        }
       
        if($collection_main_category_desc == ''){
            $collection_main_category_desc = $typeDesc;
        }
       
       
                  $data1 = array(
   ['col_name' => $collection_title, 'col_products_count' => 0, 'shopify_store_name' => $shop_name]);
                   
                    $collresid = DB::table('collectiontb')->insert($data1);
                    $last = DB::table('collectiontb')->latest('col_id')->first();
                   
                   
                    //multi sub cats
                   
                       
                   
                   
                    $data2 = array(
   ['category_id' => $collection_main_category_id, 'Clearlens_id' => '0', 'Antilens_id' => '0', 'colection_id' => $last->col_id, 'cat_disp_title' => $collection_main_category_title,
   'cat_desc' => $collection_main_category_desc, 'shopify_product_id' => '0', 'sub_cat_id' => $subcategories, 'shop_name' => $shop_name]);
 
   
                    $savedresid = DB::table('savedcollectiondata')->insert($data2);
                    $lastsaved =  DB::table('savedcollectiondata')->latest('id')->first();
                    // now call lenses for create add lense form
                   //$all_lenses = DB::table('catlensestb')->select('*')->get();
                   $html = '';
                   $html .= '<p class="addLensform-headers" data-collection-id="'.$last->col_id.'" data-category-id="'.$lastsaved->id.'" data-lenstype="'.$typeName.'">Add Lense to the '.$typeName.'</p>';
                 
                     
                    echo $html;
                   
        }
        else{
           
            echo 'Sent';
        }
   
    }
   
    /** function for fetchPrescriptionTypes **/
     public function fetchPrescriptionTypes(Request $request){
          $shop_name = $request->get('shops');
          $html = '';
          $i = 0;
          $all_prescription = DB::table('lenscategory')->select('*')->get();
         
          foreach($all_prescription as $cats){
             
               $cat_id = $cats->ID;
               $cat_name = $cats->catname;
               $cat_desc = $cats->catdesc;
               $catSlugs = str_replace(' ', '_', $cat_name);
               
               //subcats
               $subCatsdata = DB::table('lenssubcats')->where('main_cat_id', $cat_id)->get();
               
               
               
               
               $html .= '<div class="choiceinput-fields from_createCollec">';
               $html .= '<div class="customCreates_Choices">';
               $html .= '<label class="lensCats_Choices" for="prescription-type-checkbox-'.$catSlugs.'">';
               $html .= '<span class="choice-check-outer"><span class="choice-check-inner"><input data-subcat="'.$cats->hassubcats.'" data-title="'.$cat_name.'" type="checkbox" name="maincategory" id="prescription-type-checkbox-'.$catSlugs.'" class="maincatcheckbox-fields" value="'.$cat_id.'" data-item></span></span>';
               $html .= '<span class="pre-names">'.$cat_name.'</span></lable></div>';
               
               
               
                if($cats->hassubcats == 'true'){
                 
                    $html .= '<div class="choose-subcats hideData">';
               $html .= '<p class="subcat-desc">Please choose a sub-category for '.$cat_name.' </p>';
                }
               
                 
               
                foreach($subCatsdata as $subItems){
                $subSlugs = str_replace(' ', '_', $subItems->subcatname);
               $html .= '<div class="inner-subitems">
               <lable class="subcats" for="subcats">
               <span class="check-input"><input type="checkbox" name="subcats['.$i.']" value="'.$subItems->sub_id.'" class="subcategory-field"></span>
               <span class="disp-label">'.$subItems->subcatname.'</span></lable></div>
               ';
                $i++;
                }
               
               if($cats->hassubcats == 'true'){
               $html .= '</div>';
               }
               
              $html .= '</div></div>';
             
               
          }
         
          echo $html;
     }
     
     
     /*** function saveLenes ***/
     public function saveLenes(Request $request){
            $shop_name = $request->get('shops');
            $ShopUsers = new collectiontb();
            $shop_data = $ShopUsers->getShopdata($shop_name);
         
          $shop_access_token = $shop_data->password;
          $api_version = env('SHOPIFY_API_VERSION');
           
            //api header
            $header = array(
            'Content-Type: application/json',
            'X-Shopify-Access-Token:'. $shop_access_token
           );
           
           $myobj = new Curluse();
           
           
            // form data
            $collectionID = $request->get("collectionID");
            $SavedTbyID = $request->get("categoryID");
            
            
            $clearlens_gp = $request->get("clearlens-group");
            $antilens_gp = $request->get("antilens-group");
           
             if(!empty($request->get("lens_title1"))){
                 $lens_title1 = $request->get("lens_title1");
             }else{
                 $lens_title1 = 'Regular clear lens';
             }
             
             if(!empty($request->get("lens_title2"))){
                 $lens_title2 = $request->get("lens_title2");
             }else{
                 $lens_title2 = 'Anti Blue Light Lens';
             }
           
        if($clearlens_gp[0]['lens_names'] != '' || $antilens_gp[0]['antilens_names'] != ''){
              $html = '';
            $clearlens_gpCount = count($request->get("clearlens-group"));
            $antilens_gpCount = count($request->get("antilens-group"));
             
         
          /* clear lens data product created in shopify */
          if(!empty($clearlens_gp)){
            foreach($clearlens_gp as $clearL){
                if(empty($clearL['lensprice'])){
                    $pprice = 0;
                }else{
                  $pprice = $clearL['lensprice'];
                }
                
          $ClearLensdata = json_encode(array(
              "product" => array(
        "title" => $clearL['lens_names'],
        "body_html" => "Clear lens product",
        "vendor" => "lensapp",
        "product_type" => "lensapp",
        "price" => $pprice
        //"lens_names" => $clearL['rxtype']
        )

    ));
   
    if(!empty($clearL['lens_names'])){
    /* call product create api */
      $apiUrl_1 = 'https://'.$shop_name.'/admin/api/'.$api_version.'/products.json';
      $response1 = $myobj->CurlPostdata($apiUrl_1, $ClearLensdata, $header);
      if(!empty($response1)){
      $responseClear_L = json_decode($response1);
      // print_r($responseClear_L);
     
       foreach($responseClear_L as $rowClearL){
             $productClearID = $rowClearL->id;
                 
                   //save in db db table addlenstb
                   $data_clear_1 = array(
   ['lensname' => $clearL['lens_names'], 'lensprice' => $pprice, 'lenstype' => $lens_title1, 'lensRX' => 'single-vision', 'lensShopifyID' => "$productClearID", 'shopify_store' => $shop_name]);
                   
                     DB::table('addlenstb')->insert($data_clear_1);
                    $last_clear_LID = DB::table('addlenstb')->latest('id')->first();
                   
                    //update savecollectiontb
                     $newdata = array('Clearlens_id' => $last_clear_LID->id);
                     DB::table('savedcollectiondata')->where('id', $SavedTbyID)->update($newdata);
       }
      }
       
}
}

}
         
           /* anti lens data product created in shopify */
           
           if(!empty($antilens_gp)){
               //print_r($antilens_gp);
             foreach($antilens_gp as $antiL){
                 
                 if(empty($antiL['antilensprice'])){
                    $Apprice = 0;
                }else{
                  $Apprice = $antiL['antilensprice'];
                }
                 
          $AntiLensdata = json_encode(array(
              "product" => array(
        "title" => $antiL['antilens_names'],
        "body_html" => "Anti lens product",
        "vendor" => "lensapp",
        "product_type" => "lensapp",
        "price" => $antiL['antilensprice']
        //"lens_names" => $antiL['antirxtype']
        )

    ));
   
       if(!empty($antiL['antilens_names'])){
      /* call product create api */
      $apiUrl_2 = 'https://'.$shop_name.'/admin/api/'.$api_version.'/products.json';
      $response2 = $myobj->CurlPostdata($apiUrl_2, $AntiLensdata, $header);
     
      if(!empty($response2)){
      $responseAnti_L = json_decode($response2);
       
       
       foreach($responseAnti_L as $rowAntiL){
           $productAntiID = $rowAntiL->id;
                //echo $productAntiID;
       
       //save in db table addlenstb
       $data_anti_2 = array(
   ['lensname' => $antiL['antilens_names'], 'lensprice' => $Apprice, 'lenstype' => $lens_title2, 'lensRX' => 'single-vision', 'lensShopifyID' => "$productAntiID", 'shopify_store' => $shop_name]);
                   
                    DB::table('addlenstb')->insert($data_anti_2);
                    $last_anti_LID = DB::table('addlenstb')->latest('id')->first();
                   
                    //update savecollectiontb
                     $newdata2 = array('Antilens_id' => $last_anti_LID->id);
                     DB::table('savedcollectiondata')->where('id', $SavedTbyID)->update($newdata2);
                   
       }
      }
}
}

}

 $html .= '<p class="assign-headers" data-collection-id="'.$collectionID.'" data-category-id="'.$SavedTbyID.'"></p>';
 echo $html;

}else{
    echo 'Sent';
}
     }
   
   
    /** function for addassetfile **/
    public function addassetfile(Request $request){
       
      $shop_name = $request->get('shops');
     
       // check directory for folder 'pull'
    $paths = 'pull';
    $path = 'pull/'.$shop_name;
    if(is_dir('pull')) {
if (!is_dir('pull/'.$shop_name)) {
mkdir('pull/'.$shop_name);
$dataCollect = array(
   ['col_name' => 'Example Eyeglasses Collection', 'col_products_count' => 0, 'shopify_store_name' => $shop_name],
                    ['col_name' => 'Example Sunglasses Collection', 'col_products_count' => 0, 'shopify_store_name' => $shop_name]);
   
   $colModels = new collectiontb();
   $all_cols = DB::table('collectiontb')->where('shopify_store_name',$shop_name)->get();
   $val = count($all_cols);
                   // print_r($val);
   if(empty($val)){
                    $dd = $colModels->insertDefaultColls($dataCollect);
                    //echo $dd;
   }
$filepath = 'pull/'.$shop_name;
} else {
$filepath = 'pull/'.$shop_name;
}

}
}


/***fetch store products from shopify **/
public function fetchallproducts(Request $request){
         $shop_name = $request->get('shops');
            $ShopUsers = new collectiontb();
            $shop_data = $ShopUsers->getShopdata($shop_name);
         
          $shop_access_token = $shop_data->password;
          $api_version = env('SHOPIFY_API_VERSION');
           
            //api header
            $header = array(
            'Content-Type: application/json',
            'X-Shopify-Access-Token:'. $shop_access_token
           );
            
           $myobj = new Curluse();
           
           $url = 'https://'.$shop_name.'/admin/api/'.$api_version.'/products.json';
            $Data = $myobj->Curldata($url, $header);
            
            $response = json_decode($Data);
            if(!empty($response)){
                
                // now get store  currency
                $curr_url = 'https://'.$shop_name.'/admin/api/'.$api_version.'/currencies.json';
            $Data_curr = $myobj->Curldata($curr_url, $header);
            
            $responseCurr = json_decode($Data_curr);
            if(!empty($responseCurr)){
                //print_r($responseCurr);
                
            }
                
                $html = '';
                $html .= '<div class="productListsStart">';
                $html .= '<table class="productLists"><tbody>';
                $i=0;
                foreach($response as $rows){
                    $i++;
                   if(!empty($rows[$i]->images)){
                        $product_img = $rows[$i]->images[0]->src;
                   }else{
                      $product_img = ''; 
                   }
                   
                    if(!empty($rows[$i]->variants)){
                       $product_price = $rows[$i]->variants[0]->price;
                   }else{
                      $product_price = '0.00'; 
                   }
                   
                   // echo'<pre>';print_r($rows);
                    $product_id = $rows[$i]->id;
                    $product_title = $rows[$i]->title;
                   
                    
                    
                    
                    $html .= '<tr>';
                    $html .= '<td><input type="checkbox" name="myproduct['.$i.']" value="'.$product_id.'"></td>';
                    
                     $html .= '<td><img class="porductImgs" src="'.$product_img.'"></td>';
                     
                      $html .= '<td><input disabled type="text" name="productName" value="'.$product_title.'"></td>';
                      
                       $html .= '<td><input disabled type="text" name="productPrices" value="'.$product_price.'"></td>';
                    
                    
                     $html .= '</tr>';
                     
                    
                }
                
                
                 $html .= '</tbody></table>';
                 $html .= '</div>';
                 
                 echo $html;
                
            }else{
                echo '<span class="empty-results">No Products Found!</span>';
            }
           
}

/***end funtcion **/

/**assign selected products **/
public function assignProducts(Request $request){
    
       $shop_name = $request->get('shops');
            $ShopUsers = new collectiontb();
            $shop_data = $ShopUsers->getShopdata($shop_name);
         
          $shop_access_token = $shop_data->password;
          $api_version = env('SHOPIFY_API_VERSION');
           
            //api header
            $header = array(
            'Content-Type: application/json',
            'X-Shopify-Access-Token:'. $shop_access_token
           );
            
           $myobj = new Curluse();
           
           $url = 'https://'.$shop_name.'/admin/api/'.$api_version.'/products.json';
            $Data = $myobj->Curldata($url, $header);
            
            $response = json_decode($Data);
            if(!empty($response)){
                
            }
    
}

/**end function **/


/*** edit collection **/
public function editCollections(Request $request){
     $shop_name = $request->get('shops');
     $editCollecID = $request->get('editcol');
     //echo $editCollecID;
      $fetch_coldata = DB::table('collectiontb')->Where('col_id', $editCollecID)->get();
      $totalCount = count($fetch_coldata);
      if(!empty($totalCount)){
      //print_r($fetch_coldata);
      $html = '';
      $html .= '<input type="hidden" name="edit_col_ids" value="'.$editCollecID.'">';
      // collection title up
      $html .= '<div class="coldetail-container">
            <div class="collection-MainFieldarea">
            <div class="colscard-sub-heading">
            <p class="colscard-heading">Collection Title</p>
            </div>
            <div class="colscard-sub-heading">
                <p class="colsubs-heading">This title is for internal use and not visible to customers.</p>
            </div>
            <div class="Form-fields">
            <input id="collec-titles" placeholder="Eg: Select Lenses" class="form-txtfileds" name="collection_title" value="'.$fetch_coldata[0]->col_name.'" required>
            </div>
            </div>
        </div>';
      
       $fetch_prescriptionSavedData = DB::table('savedcollectiondata')->Where('colection_id', $editCollecID)->get();
       $total_SavedId = count($fetch_prescriptionSavedData);
       if(!empty($total_SavedId)){
       
        $prescriptionCatID = $fetch_prescriptionSavedData[0]->category_id;
        $prescriCatTitle = $fetch_prescriptionSavedData[0]->cat_disp_title;
        $prescriCatDesc = $fetch_prescriptionSavedData[0]->cat_desc;
        $sub_cat_id = $fetch_prescriptionSavedData[0]->sub_cat_id;
        $Clearlens_id = $fetch_prescriptionSavedData[0]->Clearlens_id;
        $Antilens_id = $fetch_prescriptionSavedData[0]->Antilens_id;
          $subcatArr = '';
         if(!empty($sub_cat_id)){
          $subcatlen = strlen($sub_cat_id);
           if($subcatlen > 0 ){
          $subcatArr = explode(',',$sub_cat_id);
           }
         }
           //print_r($subcatArr);
           
        //prescription type update
        $html .='<div id="prescripdiv" class="coldetail-container detailContainers prescription-Det">';
        $html .= '<div class="Second-FieldsecHeading">Edit Prescription Types</div>
     <p class="colsubs-heading">Select the types of prescription lenses you will add to this lens collection</p>';
        
        $html .= '<div class="CatPreType-checkbox">';
        
         $all_prescription = DB::table('lenscategory')->select('*')->get();
         $i= 0;
          foreach($all_prescription as $cats){
             
               $cat_id = $cats->ID;
               $cat_name = $cats->catname;
               $cat_desc = $cats->catdesc;
               $catSlugs = str_replace(' ', '_', $cat_name);
               
               //subcats
               $subCatsdata = DB::table('lenssubcats')->where('main_cat_id', $cat_id)->get();
               
               if($cat_id == $prescriptionCatID){
                   $catselected = 'checked';
               }else{
                   $catselected = '';
               }
               
              
               
               
               $html .= '<div class="choiceinput-fields from_createCollec">';
               $html .= '<div class="customCreates_Choices">';
               $html .= '<label class="lensCats_Choices" for="prescription-type-checkbox-'.$catSlugs.'">';
               $html .= '<span class="choice-check-outer"><span class="choice-check-inner"><input '.$catselected.' data-subcat="'.$cats->hassubcats.'" data-title="'.$cat_name.'" type="checkbox" name="maincategory" id="prescription-type-checkbox-'.$catSlugs.'" class="maincatcheckbox-fields" value="'.$cat_id.'" data-item></span></span>';
               $html .= '<span class="pre-names">'.$cat_name.'</span></lable></div>';
               
               
               
                if($cats->hassubcats == 'true'){
                 
               
                    $html .= '<div class="choose-subcats">';
               $html .= '<p class="subcat-desc">Please choose a sub-category for '.$cat_name.' </p>';
                }
               
                 
               
                foreach($subCatsdata as $subItems){
                    $SUBselected = '';
                    // subcat selected logic
                    if(!empty($subcatArr)){
               if (in_array($subItems->sub_id, $subcatArr)){
                   $SUBselected = 'checked';
               }else{
                    $SUBselected = '';
               }
                    }
                    
                    
                $subSlugs = str_replace(' ', '_', $subItems->subcatname);
               $html .= '<div class="inner-subitems">
               <lable class="subcats" for="subcats">
               <span class="check-input"><input '.$SUBselected.' type="checkbox" name="subcats['.$i.']" value="'.$subItems->sub_id.'" class="subcategory-field"></span>
               <span class="disp-label">'.$subItems->subcatname.'</span></lable></div>
               ';
                $i++;
                }
               
               if($cats->hassubcats == 'true'){
               $html .= '</div>';
               }
               
              $html .= '</div>';
             
               
          }
          
          //class="CatPreType-checkbox div closed
          $html .= '</div>';
          $html .= '<div class="colerrs error-msgs"></div>';
          $html .= '</div>';
        
          $html .= '<div class="coldetail-container detailContainers">
        <div class="display-settings-prescripType">
         <div class="field-smalldescription">
           <h5 class="field-descriptionHeading">Prescription Types Display Settings</h5>
           <p class="field-descripContent">You can add a display title or description for the selected prescription type, which are what customers see.</p>
             </div>
       
           <div style="margin-bottom: 10px;" class="display-pre-Heading">
               <span class="display-title-inputFields"><input type="text" name="category_title" class="txt-inputs" value="'.$prescriCatTitle.'" placeholder="Display Title">
               </span>
               </div>
               
           <div class="display-pre-Heading">
               <span class="display-title-inputFields">
                <textarea type="text" name="category_desc" class="txt-inputs" style="height: 84px;" placeholder="Description">'.$prescriCatDesc.'</textarea>
                 </span>
            </div>
        
    </div>
   
</div>';
      
       }
       
       
      echo $html;
     }
      
}


/**updateCollectionsOne function **/
public function updateCollectionsOne(Request $request){
      $shop_name = $request->get('shops');
      $edit_col_ids = $request->get('edit_col_ids');
      $edit_col_title = $request->get('collection_title');
      
        $collection_main_category_id = $request->get("maincategory");
        $collection_main_category_title = $request->get("category_title");
        $collection_main_category_desc = $request->get("category_desc");
        
         if(!empty($request->get("maincategory"))){
       
        if(!empty($request->get("subcats"))){
        $all_sub_catsids = $request->get("subcats");
        $totalsubcats = count($all_sub_catsids);
         $subcategories = implode(",",$all_sub_catsids);
        //echo $subcategories;
        }else{
            $subcategories = '';
        }
        
      // update collection data in collectiontb
       $upColData = array('col_name' => $edit_col_title, 'shopify_store_name' => $shop_name);
       DB::table('collectiontb')->where('col_id', $edit_col_ids)->update($upColData);
       
       $fetch_prescriptionName = DB::table('lenscategory')->Where('ID', $collection_main_category_id)->get();
          // print_r($fetch_prescriptionName);
           //exit;
                    $typeName = $fetch_prescriptionName[0]->catname;
                    $typeDesc = $fetch_prescriptionName[0]->catdesc;
                   
        if($collection_main_category_title == ''){
            $collection_main_category_title = $typeName;
        }
       
        if($collection_main_category_desc == ''){
            $collection_main_category_desc = $typeDesc;
        }
        
        //update cats data in savedtb
         $dataup2 = array('category_id' => $collection_main_category_id, 'cat_disp_title' => $collection_main_category_title, 'cat_desc' => $collection_main_category_desc, 'sub_cat_id' => $subcategories);
 
   //print_r($dataup2);
                    $upsavedresid = DB::table('savedcollectiondata')->where('colection_id', $edit_col_ids)->update($dataup2);
       
       
                   $html = '';
                   $html .= '<p class="editlenshead addLensform-headers" data-collection-id="'.$edit_col_ids.'" data-lenstype="'.$typeName.'">Update Lense to the '.$typeName.'</p>';
                 
                     
                    echo $html;
       
       
         }else{
             echo 'Sent';
         }
      
}


}

?>